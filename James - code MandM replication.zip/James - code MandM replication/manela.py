# This file contains the functions needed to run the M&M replication code

